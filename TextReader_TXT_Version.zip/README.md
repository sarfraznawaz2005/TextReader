# AutoHotkey v2 Text Reader

A professional text file management application built with AutoHotkey v2.

## Features

### Core Functionality
- **File Management**: Browse and manage .txt files from a specified folder
- **File Viewer**: View file contents in the main area with syntax highlighting
- **File Editor**: Edit files directly in the application with auto-save functionality
- **External Editor**: Double-click files to open in external editor (Notepad)

### Search Capabilities
- **Global Search**: Search across all text files in the working folder
- **In-File Search**: Search within the currently opened file
- **Match Counting**: See the number of matches for your searches
- **Context Display**: View search results with surrounding context

### File Operations
- **Add New Files**: Create new text files directly from the application
- **Rename Files**: Right-click context menu for renaming
- **Delete Files**: Right-click context menu for deletion with confirmation
- **Auto-Save**: Modified files show a save button

### User Interface
- **Professional Design**: Clean, modern interface with proper spacing and alignment
- **Responsive Layout**: Window can be resized and maximized
- **Sortable List**: Click column headers to sort files
- **Context Menus**: Right-click for file operations
- **Status Indicators**: Visual feedback for operations

### Customization
- **Working Folder**: Set any folder as your text file workspace
- **Font Size**: Adjustable font size (8-24pt) for comfortable reading
- **Persistent Settings**: All settings saved automatically

### Desktop Integration
- **Floating Button**: Draggable "My Files" button on desktop for quick access
- **Hotkey Support**: Ctrl+Alt+F to toggle floating button visibility
- **System Integration**: Opens files in default system editor

## Installation

1. Ensure AutoHotkey v2.0 or later is installed
2. Place all .ahk files in the same directory
3. Run `Main.ahk` to start the application

## Usage

### First Time Setup
1. Click the "Settings" button
2. Browse and select your working folder containing text files
3. Optionally adjust font size
4. Click "Apply"

### Working with Files
- **Single-click**: Open file in the application viewer
- **Double-click**: Open file in external editor
- **Right-click**: Access rename/delete options
- **Search**: Use the search box to find text across all files

### Keyboard Shortcuts
- **Ctrl+Alt+F**: Toggle floating button visibility

## File Structure

- `Main.ahk` - Main application entry point
- `GUI.ahk` - GUI creation and event handling
- `FileManager.ahk` - File operations and management
- `Settings.ahk` - Configuration management
- `SearchManager.ahk` - Search functionality
- `Utils.ahk` - Utility functions and helpers
- `FloatingButton.ahk` - Desktop floating button
- `TextReader.ini` - Settings storage

## Requirements

- AutoHotkey v2.0+
- Windows OS
- Write permissions for settings file

## Notes

- Settings are automatically saved in `TextReader.ini`
- The floating button only appears on desktop environments
- All file operations include proper error handling
- The application supports file names up to 255 characters